import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { SiteContent, ServiceData, ProjectData } from '../types';

const defaultContent: SiteContent = {
  logo: {
    text: "OTECH",
    iconName: "Cpu",
    mode: "text",
    image: ""
  },
  hero: {
    badge: "Innovate • Build • Scale",
    titlePrefix: "We craft digital",
    titleHighlight: "masterpieces.",
    description: "Nova is a forward-thinking digital agency specializing in high-end web development, brand strategy, and immersive user experiences.",
    ctaPrimary: "View Our Work",
    ctaSecondary: "Contact Us"
  },
  services: [
    {
      id: "1",
      title: "Web Development",
      description: "Building scalable, high-performance web applications using modern frameworks like React and Next.js.",
      iconName: "Code2"
    },
    {
      id: "2",
      title: "UI/UX Design",
      description: "Crafting intuitive and visually stunning interfaces that drive user engagement and satisfaction.",
      iconName: "PenTool"
    },
    {
      id: "3",
      title: "Digital Strategy",
      description: "Data-driven strategies to position your brand effectively in the competitive digital landscape.",
      iconName: "BarChart3"
    },
    {
      id: "4",
      title: "Global SEO",
      description: "Optimizing your digital presence to reach audiences worldwide with precision targeting.",
      iconName: "Globe"
    },
    {
      id: "5",
      title: "Mobile Solutions",
      description: "Native and cross-platform mobile applications designed for performance on all devices.",
      iconName: "Smartphone"
    },
    {
      id: "6",
      title: "Cyber Security",
      description: "Implementing robust security protocols to protect your data and user privacy.",
      iconName: "ShieldCheck"
    }
  ],
  about: {
    badge: "Who We Are",
    title: "Bridging the gap between imagination and reality.",
    description: "Founded in 2024, Nova has quickly emerged as a leader in digital innovation. We don't just build websites; we build digital ecosystems that breathe life into brands. Our team consists of senior engineers, award-winning designers, and strategic thinkers.",
    features: [
      "Agile Development Methodology",
      "User-Centric Design Philosophy",
      "24/7 Dedicated Support",
      "Scalable Cloud Infrastructure"
    ],
    stats: [
      { label: "Projects", value: "50+" },
      { label: "Experts", value: "20+" },
      { label: "Success", value: "100%" }
    ],
    imageUrl: "https://picsum.photos/800/600?grayscale"
  },
  work: [
    {
      id: "1",
      title: "Neon Finance Dashboard",
      category: "Fintech",
      imageUrl: "https://picsum.photos/600/400?random=1"
    },
    {
      id: "2",
      title: "Aura E-Commerce",
      category: "Retail",
      imageUrl: "https://picsum.photos/600/400?random=2"
    },
    {
      id: "3",
      title: "Quantum Analytics",
      category: "SaaS",
      imageUrl: "https://picsum.photos/600/400?random=3"
    },
    {
      id: "4",
      title: "Echo Social App",
      category: "Mobile",
      imageUrl: "https://picsum.photos/600/400?random=4"
    },
    {
      id: "5",
      title: "Terra Green Energy",
      category: "Corporate",
      imageUrl: "https://picsum.photos/600/400?random=5"
    },
    {
      id: "6",
      title: "Nova Health",
      category: "Healthcare",
      imageUrl: "https://picsum.photos/600/400?random=6"
    }
  ],
  contact: {
    badge: "Get in touch",
    title: "Let's start a conversation.",
    description: "Have a project in mind? We'd love to hear about it. Send us a message and we'll get back to you within 24 hours.",
    email: "hello@novadigital.com",
    phone: "+1 (555) 123-4567",
    address: "100 Innovation Drive, San Francisco, CA"
  }
};

interface ContentContextType {
  content: SiteContent;
  updateContent: (newContent: SiteContent) => void;
  resetContent: () => void;
}

const ContentContext = createContext<ContentContextType | undefined>(undefined);

export const ContentProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [content, setContent] = useState<SiteContent>(defaultContent);

  useEffect(() => {
    const savedContent = localStorage.getItem('nova_site_content');
    if (savedContent) {
      try {
        const parsed = JSON.parse(savedContent);
        // Merge with default to ensure new fields (like mode/image) exist if they were missing in old save
        setContent({ ...defaultContent, ...parsed, logo: { ...defaultContent.logo, ...parsed.logo } });
      } catch (e) {
        console.error("Failed to parse saved content", e);
      }
    }
  }, []);

  const updateContent = (newContent: SiteContent) => {
    setContent(newContent);
    localStorage.setItem('nova_site_content', JSON.stringify(newContent));
  };

  const resetContent = () => {
    setContent(defaultContent);
    localStorage.setItem('nova_site_content', JSON.stringify(defaultContent));
  };

  return (
    <ContentContext.Provider value={{ content, updateContent, resetContent }}>
      {children}
    </ContentContext.Provider>
  );
};

export const useContent = () => {
  const context = useContext(ContentContext);
  if (context === undefined) {
    throw new Error('useContent must be used within a ContentProvider');
  }
  return context;
};
import { Code2, PenTool, BarChart3, Globe, Smartphone, ShieldCheck, Zap, Database, Cloud, Cpu, Layout, Server, Hexagon } from 'lucide-react';

export const iconMap: Record<string, any> = {
  Code2,
  PenTool,
  BarChart3,
  Globe,
  Smartphone,
  ShieldCheck,
  Zap,
  Database,
  Cloud,
  Cpu,
  Layout,
  Server,
  Hexagon
};

export const getIcon = (name: string) => {
  return iconMap[name] || Code2;
};

export const availableIcons = Object.keys(iconMap);
import { LucideIcon } from 'lucide-react';

export interface NavItem {
  id: string;
  label: string;
}

export interface LogoData {
  text: string;
  iconName: string;
  image?: string;
  mode: 'text' | 'image';
}

export interface ServiceData {
  id: string;
  title: string;
  description: string;
  iconName: string;
}

export interface ProjectData {
  id: string;
  title: string;
  category: string;
  imageUrl: string;
}

export interface TestimonialItem {
  name: string;
  role: string;
  company: string;
  content: string;
  avatarUrl: string;
}

export interface HeroData {
  badge: string;
  titlePrefix: string;
  titleHighlight: string;
  description: string;
  ctaPrimary: string;
  ctaSecondary: string;
}

export interface AboutData {
  badge: string;
  title: string;
  description: string;
  features: string[];
  stats: { label: string; value: string }[];
  imageUrl: string;
}

export interface ContactData {
  badge: string;
  title: string;
  description: string;
  email: string;
  phone: string;
  address: string;
}

export interface SiteContent {
  logo: LogoData;
  hero: HeroData;
  services: ServiceData[];
  about: AboutData;
  work: ProjectData[];
  contact: ContactData;
}
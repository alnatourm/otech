import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Services from './components/Services';
import About from './components/About';
import Work from './components/Work';
import Contact from './components/Contact';
import Footer from './components/Footer';
import ControlPanel from './components/ControlPanel';
import { NavItem } from './types';
import { ContentProvider } from './context/ContentContext';

// The five tabs as requested
const navItems: NavItem[] = [
  { id: 'home', label: 'Home' },
  { id: 'services', label: 'Services' },
  { id: 'about', label: 'About' },
  { id: 'work', label: 'Work' },
  { id: 'contact', label: 'Contact' },
];

const App: React.FC = () => {
  const [isControlPanelOpen, setIsControlPanelOpen] = useState(false);

  return (
    <ContentProvider>
      <div className="min-h-screen bg-slate-950 text-slate-200 font-sans selection:bg-primary-500/30 selection:text-primary-200">
        <Navbar 
          navItems={navItems} 
          onSecretTrigger={() => setIsControlPanelOpen(true)}
        />
        
        <main>
          <Hero id="home" />
          <Services id="services" />
          <About id="about" />
          <Work id="work" />
          <Contact id="contact" />
        </main>

        <Footer />
        <ControlPanel 
          isOpen={isControlPanelOpen}
          onClose={() => setIsControlPanelOpen(false)}
        />
      </div>
    </ContentProvider>
  );
};

export default App;
import React, { useState } from 'react';
import { Settings, X, Save, RefreshCw, Plus, Trash2 } from 'lucide-react';
import { useContent } from '../context/ContentContext';
import { availableIcons } from '../utils/icons';

interface ControlPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

const ControlPanel: React.FC<ControlPanelProps> = ({ isOpen, onClose }) => {
  const { content, updateContent, resetContent } = useContent();
  const [activeTab, setActiveTab] = useState<'general' | 'hero' | 'services' | 'about' | 'work' | 'contact'>('general');

  // Local state for form handling before save
  const [localContent, setLocalContent] = useState(content);

  // Sync local state when global state changes or when panel opens
  React.useEffect(() => {
    setLocalContent(content);
  }, [content, isOpen]);

  const handleSave = () => {
    updateContent(localContent);
    alert('Changes saved successfully!');
  };

  const handleReset = () => {
    if (window.confirm('Are you sure you want to reset all content to default?')) {
      resetContent();
    }
  };

  // Helper for text inputs
  const TextInput = ({ label, value, onChange, textarea = false }: any) => (
    <div className="mb-4">
      <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">{label}</label>
      {textarea ? (
        <textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          rows={3}
          className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white focus:border-primary-500 focus:outline-none"
        />
      ) : (
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white focus:border-primary-500 focus:outline-none"
        />
      )}
    </div>
  );

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex justify-end bg-black/50 backdrop-blur-sm" onClick={onClose}>
          <div 
            className="w-full max-w-md bg-slate-950 h-full overflow-y-auto border-l border-slate-800 shadow-2xl animate-in slide-in-from-right duration-300"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="sticky top-0 bg-slate-950/95 backdrop-blur z-10 p-4 border-b border-slate-800 flex justify-between items-center">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Settings size={20} className="text-primary-500" />
                Control Panel
              </h2>
              <div className="flex items-center gap-2">
                <button 
                  onClick={handleReset}
                  className="p-2 text-slate-400 hover:text-red-400 transition-colors"
                  title="Reset to Default"
                >
                  <RefreshCw size={18} />
                </button>
                <button 
                  onClick={onClose}
                  className="p-2 text-slate-400 hover:text-white transition-colors"
                >
                  <X size={24} />
                </button>
              </div>
            </div>

            {/* Tabs */}
            <div className="flex p-2 bg-slate-900 gap-1 overflow-x-auto no-scrollbar">
              {['general', 'hero', 'services', 'about', 'work', 'contact'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab as any)}
                  className={`px-4 py-2 rounded text-sm font-medium whitespace-nowrap transition-colors ${
                    activeTab === tab 
                      ? 'bg-primary-600 text-white' 
                      : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  {tab.charAt(0).toUpperCase() + tab.slice(1)}
                </button>
              ))}
            </div>

            {/* Content Area */}
            <div className="p-6 pb-24 space-y-6">

              {/* General Settings */}
              {activeTab === 'general' && (
                <div className="space-y-4">
                  <h3 className="text-lg font-bold text-white mb-4">General Settings</h3>
                  <div className="p-4 bg-slate-900 rounded-lg border border-slate-800 mb-4">
                    <p className="text-sm text-slate-400 mb-2">
                      <span className="text-yellow-500 font-bold">Tip:</span> You can open this panel by triple-clicking the logo in the top left corner.
                    </p>
                  </div>
                  
                  <div className="mb-4">
                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 block">Logo Type</label>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setLocalContent({...localContent, logo: {...localContent.logo, mode: 'text'}})}
                        className={`flex-1 py-2 px-3 rounded text-sm font-medium border ${
                          localContent.logo.mode === 'text' 
                            ? 'bg-primary-600/20 border-primary-500 text-primary-400' 
                            : 'bg-slate-900 border-slate-700 text-slate-400 hover:bg-slate-800'
                        }`}
                      >
                        Text + Icon
                      </button>
                      <button
                         onClick={() => setLocalContent({...localContent, logo: {...localContent.logo, mode: 'image'}})}
                         className={`flex-1 py-2 px-3 rounded text-sm font-medium border ${
                          localContent.logo.mode === 'image' 
                            ? 'bg-primary-600/20 border-primary-500 text-primary-400' 
                            : 'bg-slate-900 border-slate-700 text-slate-400 hover:bg-slate-800'
                        }`}
                      >
                        Image Logo
                      </button>
                    </div>
                  </div>

                  {localContent.logo.mode === 'text' ? (
                    <>
                      <TextInput 
                        label="Brand Name (Logo Text)" 
                        value={localContent.logo.text} 
                        onChange={(v: string) => setLocalContent({...localContent, logo: {...localContent.logo, text: v}})} 
                      />
                      <div>
                        <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1 block">Logo Icon</label>
                        <select 
                          value={localContent.logo.iconName}
                          onChange={(e) => setLocalContent({...localContent, logo: {...localContent.logo, iconName: e.target.value}})}
                          className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white text-sm focus:border-primary-500 focus:outline-none"
                        >
                          {availableIcons.map(icon => (
                            <option key={icon} value={icon}>{icon}</option>
                          ))}
                        </select>
                      </div>
                    </>
                  ) : (
                    <>
                      <TextInput 
                        label="Logo Image URL" 
                        value={localContent.logo.image || ''} 
                        onChange={(v: string) => setLocalContent({...localContent, logo: {...localContent.logo, image: v}})} 
                      />
                       <p className="text-xs text-slate-500 italic">
                        Paste the URL of your logo image here.
                      </p>
                    </>
                  )}
                </div>
              )}
              
              {/* Hero Settings */}
              {activeTab === 'hero' && (
                <div className="space-y-4">
                  <h3 className="text-lg font-bold text-white mb-4">Hero Section</h3>
                  <TextInput 
                    label="Badge Text" 
                    value={localContent.hero.badge} 
                    onChange={(v: string) => setLocalContent({...localContent, hero: {...localContent.hero, badge: v}})} 
                  />
                  <TextInput 
                    label="Title Prefix" 
                    value={localContent.hero.titlePrefix} 
                    onChange={(v: string) => setLocalContent({...localContent, hero: {...localContent.hero, titlePrefix: v}})} 
                  />
                  <TextInput 
                    label="Title Highlight" 
                    value={localContent.hero.titleHighlight} 
                    onChange={(v: string) => setLocalContent({...localContent, hero: {...localContent.hero, titleHighlight: v}})} 
                  />
                  <TextInput 
                    label="Description" 
                    value={localContent.hero.description} 
                    onChange={(v: string) => setLocalContent({...localContent, hero: {...localContent.hero, description: v}})} 
                    textarea
                  />
                  <div className="grid grid-cols-1 gap-4">
                    <TextInput 
                      label="Contact Button Text" 
                      value={localContent.hero.ctaSecondary} 
                      onChange={(v: string) => setLocalContent({...localContent, hero: {...localContent.hero, ctaSecondary: v}})} 
                    />
                  </div>
                </div>
              )}

              {/* Services Settings */}
              {activeTab === 'services' && (
                <div className="space-y-6">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-bold text-white">Services List</h3>
                    <button 
                      onClick={() => {
                        const newService = {
                          id: Date.now().toString(),
                          title: 'New Service',
                          description: 'Description here...',
                          iconName: 'Code2'
                        };
                        setLocalContent({...localContent, services: [...localContent.services, newService]});
                      }}
                      className="text-xs bg-slate-800 hover:bg-slate-700 text-white px-3 py-1.5 rounded flex items-center gap-1"
                    >
                      <Plus size={14} /> Add Service
                    </button>
                  </div>
                  
                  {localContent.services.map((service, idx) => (
                    <div key={service.id} className="bg-slate-900 p-4 rounded-lg border border-slate-800">
                      <div className="flex justify-between mb-2">
                        <span className="text-xs text-slate-500">Service #{idx + 1}</span>
                        <button 
                          onClick={() => {
                            const newServices = localContent.services.filter(s => s.id !== service.id);
                            setLocalContent({...localContent, services: newServices});
                          }}
                          className="text-red-400 hover:text-red-300"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                      <div className="space-y-3">
                        <input
                          type="text"
                          value={service.title}
                          onChange={(e) => {
                            const newServices = [...localContent.services];
                            newServices[idx].title = e.target.value;
                            setLocalContent({...localContent, services: newServices});
                          }}
                          className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white text-sm"
                          placeholder="Service Title"
                        />
                        <textarea
                          value={service.description}
                          onChange={(e) => {
                            const newServices = [...localContent.services];
                            newServices[idx].description = e.target.value;
                            setLocalContent({...localContent, services: newServices});
                          }}
                          className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white text-sm"
                          placeholder="Service Description"
                          rows={2}
                        />
                        <div>
                          <label className="text-xs text-slate-500 mb-1 block">Icon</label>
                          <select 
                            value={service.iconName}
                            onChange={(e) => {
                              const newServices = [...localContent.services];
                              newServices[idx].iconName = e.target.value;
                              setLocalContent({...localContent, services: newServices});
                            }}
                            className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white text-sm"
                          >
                            {availableIcons.map(icon => (
                              <option key={icon} value={icon}>{icon}</option>
                            ))}
                          </select>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* About Settings */}
              {activeTab === 'about' && (
                <div className="space-y-4">
                  <h3 className="text-lg font-bold text-white mb-4">About Section</h3>
                  <TextInput 
                    label="Badge Text" 
                    value={localContent.about.badge} 
                    onChange={(v: string) => setLocalContent({...localContent, about: {...localContent.about, badge: v}})} 
                  />
                  <TextInput 
                    label="Title" 
                    value={localContent.about.title} 
                    onChange={(v: string) => setLocalContent({...localContent, about: {...localContent.about, title: v}})} 
                    textarea
                  />
                  <TextInput 
                    label="Description" 
                    value={localContent.about.description} 
                    onChange={(v: string) => setLocalContent({...localContent, about: {...localContent.about, description: v}})} 
                    textarea
                  />
                  <TextInput 
                    label="Image URL" 
                    value={localContent.about.imageUrl} 
                    onChange={(v: string) => setLocalContent({...localContent, about: {...localContent.about, imageUrl: v}})} 
                  />
                  
                  <div className="pt-4 border-t border-slate-800">
                    <h4 className="text-sm font-bold text-white mb-2">Features List</h4>
                    {localContent.about.features.map((feature, idx) => (
                      <div key={idx} className="flex gap-2 mb-2">
                        <input
                          type="text"
                          value={feature}
                          onChange={(e) => {
                            const newFeatures = [...localContent.about.features];
                            newFeatures[idx] = e.target.value;
                            setLocalContent({...localContent, about: {...localContent.about, features: newFeatures}});
                          }}
                          className="flex-1 bg-slate-900 border border-slate-700 rounded p-2 text-white text-sm"
                        />
                        <button 
                          onClick={() => {
                            const newFeatures = localContent.about.features.filter((_, i) => i !== idx);
                            setLocalContent({...localContent, about: {...localContent.about, features: newFeatures}});
                          }}
                          className="text-red-400 p-2"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    ))}
                    <button 
                      onClick={() => {
                        setLocalContent({...localContent, about: {...localContent.about, features: [...localContent.about.features, "New Feature"]}});
                      }}
                      className="text-xs text-primary-400 hover:text-primary-300 flex items-center gap-1 mt-2"
                    >
                      <Plus size={14} /> Add Feature
                    </button>
                  </div>
                </div>
              )}

              {/* Work Settings */}
              {activeTab === 'work' && (
                <div className="space-y-6">
                   <div className="flex justify-between items-center">
                    <h3 className="text-lg font-bold text-white">Projects List</h3>
                    <button 
                      onClick={() => {
                        const newProject = {
                          id: Date.now().toString(),
                          title: 'New Project',
                          category: 'Web Design',
                          imageUrl: 'https://picsum.photos/600/400'
                        };
                        setLocalContent({...localContent, work: [...localContent.work, newProject]});
                      }}
                      className="text-xs bg-slate-800 hover:bg-slate-700 text-white px-3 py-1.5 rounded flex items-center gap-1"
                    >
                      <Plus size={14} /> Add Project
                    </button>
                  </div>

                  {localContent.work.map((project, idx) => (
                    <div key={project.id} className="bg-slate-900 p-4 rounded-lg border border-slate-800">
                      <div className="flex justify-between mb-2">
                        <span className="text-xs text-slate-500">Project #{idx + 1}</span>
                        <button 
                          onClick={() => {
                            const newWork = localContent.work.filter(p => p.id !== project.id);
                            setLocalContent({...localContent, work: newWork});
                          }}
                          className="text-red-400 hover:text-red-300"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                      <div className="space-y-3">
                        <input
                          type="text"
                          value={project.title}
                          onChange={(e) => {
                            const newWork = [...localContent.work];
                            newWork[idx].title = e.target.value;
                            setLocalContent({...localContent, work: newWork});
                          }}
                          className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white text-sm"
                          placeholder="Project Title"
                        />
                         <input
                          type="text"
                          value={project.category}
                          onChange={(e) => {
                            const newWork = [...localContent.work];
                            newWork[idx].category = e.target.value;
                            setLocalContent({...localContent, work: newWork});
                          }}
                          className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white text-sm"
                          placeholder="Category"
                        />
                        <input
                          type="text"
                          value={project.imageUrl}
                          onChange={(e) => {
                            const newWork = [...localContent.work];
                            newWork[idx].imageUrl = e.target.value;
                            setLocalContent({...localContent, work: newWork});
                          }}
                          className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white text-sm"
                          placeholder="Image URL"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Contact Settings */}
              {activeTab === 'contact' && (
                <div className="space-y-4">
                  <h3 className="text-lg font-bold text-white mb-4">Contact Info</h3>
                  <TextInput 
                    label="Badge Text" 
                    value={localContent.contact.badge} 
                    onChange={(v: string) => setLocalContent({...localContent, contact: {...localContent.contact, badge: v}})} 
                  />
                  <TextInput 
                    label="Title" 
                    value={localContent.contact.title} 
                    onChange={(v: string) => setLocalContent({...localContent, contact: {...localContent.contact, title: v}})} 
                  />
                  <TextInput 
                    label="Description" 
                    value={localContent.contact.description} 
                    onChange={(v: string) => setLocalContent({...localContent, contact: {...localContent.contact, description: v}})} 
                    textarea
                  />
                  <div className="border-t border-slate-800 pt-4 space-y-4">
                    <TextInput 
                      label="Email" 
                      value={localContent.contact.email} 
                      onChange={(v: string) => setLocalContent({...localContent, contact: {...localContent.contact, email: v}})} 
                    />
                     <TextInput 
                      label="Phone" 
                      value={localContent.contact.phone} 
                      onChange={(v: string) => setLocalContent({...localContent, contact: {...localContent.contact, phone: v}})} 
                    />
                     <TextInput 
                      label="Address" 
                      value={localContent.contact.address} 
                      onChange={(v: string) => setLocalContent({...localContent, contact: {...localContent.contact, address: v}})} 
                    />
                  </div>
                </div>
              )}

            </div>

            {/* Footer Actions */}
            <div className="absolute bottom-0 left-0 w-full p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between z-20">
              <span className="text-xs text-slate-500">
                Changes are saved to your browser
              </span>
              <button
                onClick={handleSave}
                className="bg-primary-600 hover:bg-primary-500 text-white px-6 py-2 rounded-lg font-semibold flex items-center gap-2 transition-colors shadow-lg shadow-primary-900/20"
              >
                <Save size={18} />
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default ControlPanel;
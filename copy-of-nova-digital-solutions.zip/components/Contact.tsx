import React, { useState } from 'react';
import { Mail, MapPin, Phone, Send } from 'lucide-react';
import { useContent } from '../context/ContentContext';

interface ContactProps {
  id: string;
}

const Contact: React.FC<ContactProps> = ({ id }) => {
  const { content } = useContent();
  const { contact } = content;
  const [formStatus, setFormStatus] = useState<'idle' | 'submitting' | 'success'>('idle');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormStatus('submitting');
    // Simulate API call
    setTimeout(() => {
      setFormStatus('success');
      setTimeout(() => setFormStatus('idle'), 3000);
    }, 1500);
  };

  return (
    <section id={id} className="py-24 bg-gradient-to-b from-slate-900 to-slate-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          
          {/* Contact Info */}
          <div>
            <h2 className="text-primary-500 font-semibold tracking-wide uppercase text-sm mb-2">{contact.badge}</h2>
            <h3 className="text-3xl md:text-4xl font-bold text-white mb-6">{contact.title}</h3>
            <p className="text-slate-400 text-lg mb-10 leading-relaxed">
              {contact.description}
            </p>

            <div className="space-y-8">
              <div className="flex items-start space-x-4">
                <div className="bg-slate-800 p-3 rounded-lg text-primary-400">
                  <Mail size={24} />
                </div>
                <div>
                  <h4 className="text-white font-medium text-lg">Email Us</h4>
                  <p className="text-slate-400">{contact.email}</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-slate-800 p-3 rounded-lg text-primary-400">
                  <Phone size={24} />
                </div>
                <div>
                  <h4 className="text-white font-medium text-lg">Call Us</h4>
                  <p className="text-slate-400">{contact.phone}</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-slate-800 p-3 rounded-lg text-primary-400">
                  <MapPin size={24} />
                </div>
                <div>
                  <h4 className="text-white font-medium text-lg">Visit Us</h4>
                  <p className="text-slate-400">{contact.address}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-slate-900 border border-slate-800 p-8 rounded-2xl shadow-xl">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label htmlFor="name" className="text-sm font-medium text-slate-300">First Name</label>
                  <input 
                    type="text" 
                    id="name" 
                    required
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-colors"
                    placeholder="John"
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="lastname" className="text-sm font-medium text-slate-300">Last Name</label>
                  <input 
                    type="text" 
                    id="lastname" 
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-colors"
                    placeholder="Doe"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label htmlFor="email" className="text-sm font-medium text-slate-300">Email Address</label>
                <input 
                  type="email" 
                  id="email" 
                  required
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-colors"
                  placeholder="john@example.com"
                />
              </div>

              <div className="space-y-2">
                <label htmlFor="message" className="text-sm font-medium text-slate-300">Message</label>
                <textarea 
                  id="message" 
                  rows={4}
                  required
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-colors"
                  placeholder="Tell us about your project..."
                />
              </div>

              <button 
                type="submit" 
                disabled={formStatus === 'submitting' || formStatus === 'success'}
                className={`w-full py-4 rounded-lg font-bold text-white flex items-center justify-center space-x-2 transition-all duration-300 ${
                  formStatus === 'success' 
                    ? 'bg-green-600 hover:bg-green-700' 
                    : 'bg-primary-600 hover:bg-primary-500 shadow-lg shadow-primary-600/20'
                }`}
              >
                {formStatus === 'submitting' ? (
                  <span>Sending...</span>
                ) : formStatus === 'success' ? (
                  <span>Message Sent!</span>
                ) : (
                  <>
                    <span>Send Message</span>
                    <Send size={18} />
                  </>
                )}
              </button>
            </form>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Contact;

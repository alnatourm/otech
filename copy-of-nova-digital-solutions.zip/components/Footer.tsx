import React from 'react';
import { Twitter, Github, Linkedin, Instagram } from 'lucide-react';
import { useContent } from '../context/ContentContext';
import { getIcon } from '../utils/icons';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  const { content } = useContent();
  const LogoIcon = getIcon(content.logo.iconName);

  return (
    <footer className="bg-slate-950 border-t border-slate-900 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              {content.logo.mode === 'image' && content.logo.image ? (
                <img 
                  src={content.logo.image} 
                  alt={content.logo.text} 
                  className="h-10 w-auto object-contain" 
                />
              ) : (
                <>
                  <LogoIcon className="w-8 h-8 text-primary-500 fill-primary-500/10" />
                  <span className="text-2xl font-bold tracking-tighter text-white">{content.logo.text}</span>
                </>
              )}
            </div>
            <p className="text-slate-400 max-w-sm">
              We are a digital agency dedicated to crafting unique digital experiences 
              that help ambitious brands master the modern web.
            </p>
          </div>

          <div>
            <h4 className="text-white font-bold mb-4">Navigation</h4>
            <ul className="space-y-2">
              {['Home', 'Services', 'About', 'Work', 'Contact'].map((item) => (
                <li key={item}>
                  <button 
                    onClick={() => document.getElementById(item.toLowerCase())?.scrollIntoView({ behavior: 'smooth' })}
                    className="text-slate-400 hover:text-primary-400 transition-colors"
                  >
                    {item}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-4">Social</h4>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center text-slate-400 hover:bg-primary-600 hover:text-white transition-all">
                <Twitter size={20} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center text-slate-400 hover:bg-primary-600 hover:text-white transition-all">
                <Github size={20} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center text-slate-400 hover:bg-primary-600 hover:text-white transition-all">
                <Linkedin size={20} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center text-slate-400 hover:bg-primary-600 hover:text-white transition-all">
                <Instagram size={20} />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-900 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-slate-500 text-sm">
            &copy; {currentYear} {content.logo.text} Solutions. All rights reserved.
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="text-slate-500 text-sm hover:text-slate-300">Privacy Policy</a>
            <a href="#" className="text-slate-500 text-sm hover:text-slate-300">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
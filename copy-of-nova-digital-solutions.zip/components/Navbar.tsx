import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import { NavItem } from '../types';
import { useContent } from '../context/ContentContext';
import { getIcon } from '../utils/icons';

interface NavbarProps {
  navItems: NavItem[];
  onSecretTrigger: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ navItems, onSecretTrigger }) => {
  const { content } = useContent();
  const [activeId, setActiveId] = useState<string>(navItems[0].id);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [logoClickCount, setLogoClickCount] = useState(0);

  const LogoIcon = getIcon(content.logo.iconName);

  useEffect(() => {
    const handleScroll = () => {
      // Handle background transparency
      setIsScrolled(window.scrollY > 50);

      // Handle active tab detection
      const scrollPosition = window.scrollY + 100; // Offset

      for (const item of navItems) {
        const element = document.getElementById(item.id);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveId(item.id);
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [navItems]);

  // Secret Trigger Logic
  useEffect(() => {
    if (logoClickCount === 0) return;

    const timer = setTimeout(() => {
      setLogoClickCount(0);
    }, 500); // Reset count if no click within 500ms

    if (logoClickCount >= 3) {
      onSecretTrigger();
      setLogoClickCount(0);
    }

    return () => clearTimeout(timer);
  }, [logoClickCount, onSecretTrigger]);

  const handleLogoClick = () => {
    scrollToSection('home');
    setLogoClickCount((prev) => prev + 1);
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 80; // Navbar height
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
      setIsMobileMenuOpen(false);
    }
  };

  return (
    <nav 
      className={`fixed top-0 w-full z-50 transition-all duration-300 border-b ${
        isScrolled 
          ? 'bg-slate-950/80 backdrop-blur-md border-slate-800 py-4 shadow-lg' 
          : 'bg-transparent border-transparent py-6'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <div 
            className="flex items-center space-x-2 cursor-pointer group select-none"
            onClick={handleLogoClick}
          >
            {content.logo.mode === 'image' && content.logo.image ? (
              <img 
                src={content.logo.image} 
                alt={content.logo.text} 
                className="h-10 w-auto object-contain transition-transform duration-500 group-hover:scale-105" 
              />
            ) : (
              <>
                <LogoIcon className="w-8 h-8 text-primary-500 fill-primary-500/10 group-hover:rotate-180 transition-transform duration-500" />
                <span className="text-2xl font-bold tracking-tighter text-white">{content.logo.text}</span>
              </>
            )}
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex space-x-1 bg-slate-900/50 p-1.5 rounded-full border border-slate-800/50 backdrop-blur-sm">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className={`px-5 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                  activeId === item.id
                    ? 'bg-primary-600 text-white shadow-lg shadow-primary-500/25'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-slate-300 hover:text-white p-2"
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {isMobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-slate-950 border-b border-slate-800 shadow-xl">
          <div className="flex flex-col p-4 space-y-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className={`w-full text-left px-4 py-3 rounded-lg text-base font-medium transition-colors ${
                  activeId === item.id
                    ? 'bg-primary-600/10 text-primary-400'
                    : 'text-slate-400 hover:text-white hover:bg-slate-900'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
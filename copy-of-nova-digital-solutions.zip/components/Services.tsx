import React from 'react';
import { motion } from 'framer-motion';
import { useContent } from '../context/ContentContext';
import { getIcon } from '../utils/icons';

interface ServicesProps {
  id: string;
}

const Services: React.FC<ServicesProps> = ({ id }) => {
  const { content } = useContent();

  return (
    <section id={id} className="py-24 bg-slate-950 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-primary-500 font-semibold tracking-wide uppercase text-sm">Our Expertise</h2>
          <h3 className="mt-2 text-3xl md:text-4xl font-bold text-white">Solutions for the modern web</h3>
          <p className="mt-4 max-w-2xl mx-auto text-slate-400">
            We combine technical depth with design mastery to solve complex problems.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {content.services.map((service, index) => {
            const IconComponent = getIcon(service.iconName);
            return (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
                className="bg-slate-900/50 border border-slate-800 p-8 rounded-2xl hover:border-primary-500/30 hover:bg-slate-900 transition-all duration-300 group"
              >
                <div className="w-12 h-12 bg-slate-800 rounded-lg flex items-center justify-center mb-6 group-hover:bg-primary-600 transition-colors duration-300">
                  <IconComponent className="w-6 h-6 text-primary-400 group-hover:text-white" />
                </div>
                <h4 className="text-xl font-bold text-white mb-3">{service.title}</h4>
                <p className="text-slate-400 leading-relaxed">{service.description}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Services;

import React from 'react';
import { motion } from 'framer-motion';
import { ExternalLink } from 'lucide-react';
import { useContent } from '../context/ContentContext';

interface WorkProps {
  id: string;
}

const Work: React.FC<WorkProps> = ({ id }) => {
  const { content } = useContent();

  return (
    <section id={id} className="py-24 bg-slate-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div>
            <h2 className="text-primary-500 font-semibold tracking-wide uppercase text-sm">Selected Work</h2>
            <h3 className="mt-2 text-3xl md:text-4xl font-bold text-white">Building the future.</h3>
          </div>
          <button className="mt-6 md:mt-0 text-white border-b border-primary-500 pb-1 hover:text-primary-400 transition-colors self-start">
            View all projects
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {content.work.map((project, index) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
              className="group relative overflow-hidden rounded-xl bg-slate-900 border border-slate-800"
            >
              <div className="aspect-w-16 aspect-h-12 overflow-hidden">
                <img 
                  src={project.imageUrl} 
                  alt={project.title} 
                  className="object-cover w-full h-64 group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent opacity-90 flex flex-col justify-end p-6">
                <div>
                  <span className="text-primary-400 text-sm font-medium mb-2 block">{project.category}</span>
                  <h4 className="text-xl font-bold text-white mb-2">{project.title}</h4>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Work;